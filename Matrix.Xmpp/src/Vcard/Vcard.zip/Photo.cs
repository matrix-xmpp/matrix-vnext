﻿using System;
using System.IO;
#if SILVERLIGHT
using System.Windows.Media.Imaging;
#else
#if !MONOTOUCH
using System.Drawing;
using System.Drawing.Imaging;
using System.Net;
#endif
#endif

using Matrix.Xml;

namespace Matrix.Xmpp.Vcard
{
    /// <summary>
    /// Photo in <see cref="Vcard"/>
    /// </summary>
    public class Photo : XmppXElement
    {
        /*
        <!-- Photograph property. Value is either a BASE64 encoded
            binary value or a URI to the external content. -->
        <!ELEMENT PHOTO ((TYPE, BINVAL) | EXTVAL)>
        */

        #region << Constructors >>
        /// <summary>
        /// Initializes a new instance of the <see cref="Photo"/> class.
        /// </summary>
        public Photo()
            : base(Uri.VCARD, "PHOTO")
        {
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Photo"/> class.
        /// </summary>
        /// <param name="imageBytes">The image bytes.</param>
        /// <param name="imageFormat">The image format.</param>
        public Photo(byte[] imageBytes, ImageFormat imageFormat) : this()
        {
            SetImageBytes(imageBytes);
            SetImageFormat(imageFormat);
        }

        /// <summary>
        /// Initializes a new instance of the <see cref="Photo"/> class.
        /// </summary>
        /// <param name="uri">The URI.</param>
        public Photo(System.Uri uri) : this()
        {
            Extval = uri.AbsoluteUri;
        }
        #endregion

        /// <summary>
        /// Gets the image.
        /// </summary>
        /// <value>The image.</value>
#if SILVERLIGHT
        public BitmapImage Image
#else
        public Image Image
#endif
		{
			get
			{
				try
				{
					if (HasTag("BINVAL"))
					{
						byte[] pic = Convert.FromBase64String(GetTag("BINVAL"));
					    var ms = new MemoryStream(pic, 0, pic.Length);

#if SILVERLIGHT
                        var bmp = new BitmapImage();
                        bmp.SetSource(ms);

						return bmp;
#else
                        return new Bitmap(ms);
#endif
					}
				    if (HasTag("EXTVAL"))
				    {     
#if SILVERLIGHT
				        var bmp = new BitmapImage();
				        bmp.UriSource = new System.Uri(Extval, UriKind.Absolute);                        
				        return bmp;
#else
                        WebRequest req = WebRequest.Create(this.Extval);
						WebResponse response = req.GetResponse();
						return new Bitmap(response.GetResponseStream());
#endif
				    }
				    return null;
				}
				catch
				{
					return null;
				}
			}
        }

        #region << internal members >>
        /// <summary>
        /// Gets or sets the image type.
        /// </summary>
        /// <value>The image type.</value>
        internal string Type
        {
            get { return GetTag("TYPE"); }
            set { SetTag("TYPE", value); }
        }

        /// <summary>
        /// Gets or sets the binval.
        /// </summary>
        /// <value>The binval.</value>
        public byte[] Binval
        {
            get
            {
                if (HasTag("BINVAL"))
                    return Convert.FromBase64String(GetTag("BINVAL"));
                return
                    null;
            }
            set { SetTag("BINVAL", Convert.ToBase64String(value)); }
        }

        /// <summary>
        /// Gets or sets the extval.
        /// </summary>
        /// <value>The extval.</value>
        internal string Extval
        {
            get { return GetTag("EXTVAL"); }
            set { SetTag("EXTVAL", value); }
        }

        /// <summary>
        /// Sets the image format.
        /// </summary>
        /// <param name="imgFormat">The img format.</param>
        internal void SetImageFormat(ImageFormat imgFormat)
        {
            string val = "";

            if (imgFormat == ImageFormat.Jpeg)
                val = "image/jpeg";
            else if (imgFormat == ImageFormat.Png)
                val = "image/png";
#if WIN            
            else if (imgFormat == ImageFormat.Gif)
                val = "image/gif";
            else if (imgFormat == ImageFormat.Tiff)
                val = "image/tiff";
#endif
            Type = val;
        }

        /// <summary>
        /// Sets the image bytes.
        /// </summary>
        /// <param name="image">The image.</param>
        internal void SetImageBytes(byte[] image)
        {
            Binval = image;
        }
        #endregion
    }
}